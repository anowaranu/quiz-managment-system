# Quiz-Management-System
Java Application for Quiz Management
# Description
This is a simple java application for quiz management. It includes basically two modules one is for admin for addition and removal of questions of quiz and the second module is for user who wants the attempt the quiz.
# Technology Used
NetBeans, Java and MySQL
